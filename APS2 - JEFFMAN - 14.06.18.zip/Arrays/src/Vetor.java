import java.util.Arrays;

public class Vetor {

	
	// Declarando e Inicializando um array de Aluno com capacidade 100.
	  private Aluno[] alunos = new Aluno[100];
	  
	  private int totalDeAlunos = 0;
	
	public static void main(String[] args) {
		
	}
	
	public void adiciona(Aluno aluno) {
		this.alunos[this.totalDeAlunos] = aluno;
	    this.totalDeAlunos++;
	}
	
	public String toString1() {
		  if (this.totalDeAlunos == 0) {
		    return "[]";
		  }

		  StringBuilder builder = new StringBuilder();
		  builder.append("[");

		  for (int i = 0; i < this.totalDeAlunos - 1; i++) {
		    builder.append(this.alunos[i]);
		    builder.append(", ");
		  }

		  builder.append(this.alunos[this.totalDeAlunos - 1]);
		  builder.append("]");

		  return builder.toString();
		}

	public void adiciona(int i, Aluno a1) {
		// TODO Auto-generated method stub
		
	}

	public Aluno pega(int posicao) {
		return null;
	    // implementa��o
	  }

	  public void remove(int posicao) {
	    // implementa��o
	  }

	  public boolean contem(Aluno aluno) {
		return false;
	    // implementa��o
	  }

	  public int tamanho() {
		return totalDeAlunos;
	    // implementa��o
	  }
	  
	  public String toString() {
	    return Arrays.toString(alunos);
	  }
}

